#!/bin/bash
# ============================================================
#  ScrollSwitch 一键安装
#  做三件事：把 App 复制到「应用程序」、注册为登录启动项、立刻运行。
#  不修改任何系统设置，不需要管理员密码，不联网。
# ============================================================

set -u
cd "$(dirname "$0")" || exit 1
SCRIPT_DIR="$(pwd)"
APP_NAME="ScrollSwitch.app"
LABEL="com.joelab.scrollswitch.agent"
BUNDLE_ID="com.joelab.scrollswitch"
SRC="${SCRIPT_DIR}/${APP_NAME}"

pause_exit() {
    echo
    if [ -t 0 ]; then printf "按回车键关闭本窗口…"; read -r _; fi
    exit "${1:-0}"
}

echo "======================================"
echo "  ScrollSwitch 安装程序"
echo "======================================"
echo

if [ ! -d "${SRC}" ]; then
    echo "✗ 找不到 ${APP_NAME}"
    echo "  请确认「安装.command」「卸载.command」和「${APP_NAME}」在同一个文件夹里。"
    pause_exit 1
fi

if [ -w /Applications ]; then
    DEST="/Applications/${APP_NAME}"
else
    mkdir -p "${HOME}/Applications"
    DEST="${HOME}/Applications/${APP_NAME}"
fi

echo "→ 停止正在运行的旧版本"
launchctl bootout "gui/$(id -u)/${LABEL}" >/dev/null 2>&1 || true
pkill -x ScrollSwitch >/dev/null 2>&1 || true
sleep 0.6

echo "→ 校验安装包完整性"
if codesign --verify --deep --strict "${SRC}" >/dev/null 2>&1; then
    echo "  签名校验通过"
else
    echo "  ! 签名校验未通过：安装包可能被修改或下载不完整"
fi

echo "→ 安装到 ${DEST}"
rm -rf "${DEST}"
mkdir -p "$(dirname "${DEST}")"
if ! ditto "${SRC}" "${DEST}"; then
    echo "✗ 复制失败（目标位置可能没有写入权限）"
    pause_exit 1
fi
xattr -dr com.apple.quarantine "${DEST}" >/dev/null 2>&1 || true
chmod +x "${DEST}/Contents/MacOS/ScrollSwitch"

echo "→ 注册登录启动项"
PLIST="${HOME}/Library/LaunchAgents/${LABEL}.plist"
mkdir -p "${HOME}/Library/LaunchAgents"
cat > "${PLIST}" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>${LABEL}</string>
	<key>ProgramArguments</key>
	<array>
		<string>${DEST}/Contents/MacOS/ScrollSwitch</string>
	</array>
	<key>RunAtLoad</key>
	<true/>
	<key>KeepAlive</key>
	<dict>
		<key>SuccessfulExit</key>
		<false/>
	</dict>
	<key>ProcessType</key>
	<string>Interactive</string>
	<key>LimitLoadToSessionType</key>
	<string>Aqua</string>
	<key>ThrottleInterval</key>
	<integer>10</integer>
</dict>
</plist>
PLISTEOF
chmod 644 "${PLIST}"
launchctl bootout "gui/$(id -u)" "${PLIST}" >/dev/null 2>&1 || true
BOOT_OK=0
if launchctl bootstrap "gui/$(id -u)" "${PLIST}" >/dev/null 2>&1; then
    BOOT_OK=1
else
    launchctl load -w "${PLIST}" >/dev/null 2>&1 || true
    if launchctl print "gui/$(id -u)/${LABEL}" >/dev/null 2>&1; then BOOT_OK=1; fi
fi

if [ "${BOOT_OK}" -eq 1 ]; then
    echo "  登录项注册成功，下次开机自动启动"
else
    echo "  ! 登录项暂时没能注册成功（系统 launchd 拒绝，常见于刚卸载又重装的场景）"
    echo "    设置文件已就位，下次登录会自动加载；也可以稍后重新运行本脚本。"
fi

echo "→ 启动"
launchctl kickstart -k "gui/$(id -u)/${LABEL}" >/dev/null 2>&1 || open "${DEST}"
sleep 1.5

if pgrep -x ScrollSwitch >/dev/null 2>&1; then
    echo "  已启动，菜单栏顶部应该出现了图标"
else
    echo "  ! 没有检测到进程，请手动双击 ${DEST}"
fi

cat <<'TIP'

--------------------------------------
安装完成

最后一步（只需一次）：
  点击菜单栏新出现的图标（未授权时是 ⚠️ 三角形）
  →「打开「辅助功能」设置」
  → 在列表里勾选 ScrollSwitch
  图标变成鼠标样式即代表已生效，滚动一下试试。

卸载：
  双击「卸载.command」，或点菜单栏图标 →「卸载 ScrollSwitch…」
  两种方式都会删干净：应用、登录项、偏好、缓存、日志、授权记录。
--------------------------------------
TIP

pause_exit 0
