#!/bin/bash
# ============================================================
#  ScrollSwitch 一键卸载
#  删除：应用本体、登录启动项、偏好设置、缓存、日志、辅助功能授权记录。
#  不改动任何系统设置，结束时逐项检查残留。
# ============================================================

set -u
LABEL="com.joelab.scrollswitch.agent"
BUNDLE_ID="com.joelab.scrollswitch"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

pause_exit() {
    echo
    if [ -t 0 ]; then printf "按回车键关闭本窗口…"; read -r _; fi
    exit "${1:-0}"
}

echo "======================================"
echo "  ScrollSwitch 卸载程序"
echo "======================================"
echo

echo "→ 退出程序"
launchctl bootout "gui/$(id -u)/${LABEL}" >/dev/null 2>&1 || true
pkill -x ScrollSwitch >/dev/null 2>&1 || true
sleep 0.8
pkill -9 -x ScrollSwitch >/dev/null 2>&1 || true

echo "→ 删除登录启动项"
rm -f "${HOME}/Library/LaunchAgents/${LABEL}.plist"

echo "→ 清除辅助功能授权记录"
if tccutil reset Accessibility "${BUNDLE_ID}" >/dev/null 2>&1; then
    echo "  已清除"
else
    echo "  （没有找到授权记录，跳过）"
fi

echo "→ 删除应用本体与用户数据"
for APP in "/Applications/ScrollSwitch.app" "${HOME}/Applications/ScrollSwitch.app"; do
    if [ -d "${APP}" ]; then
        "${LSREGISTER}" -u "${APP}" >/dev/null 2>&1 || true
        rm -rf "${APP}"
        echo "  已删除 ${APP}"
    fi
done
defaults delete "${BUNDLE_ID}" >/dev/null 2>&1 || true
rm -f "${HOME}/Library/Preferences/${BUNDLE_ID}.plist"
rm -rf "${HOME}/Library/Application Support/ScrollSwitch"
rm -rf "${HOME}/Library/Caches/${BUNDLE_ID}"
rm -rf "${HOME}/Library/Saved Application State/${BUNDLE_ID}.savedState"
rm -rf "${HOME}/Library/HTTPStorages/${BUNDLE_ID}"
rm -f "${HOME}/Library/Logs/ScrollSwitch.log"

echo
echo "→ 残留检查"
LEFT=0

check_path() {
    if [ -e "${1}" ]; then
        echo "  ✗ 残留：${1}"
        LEFT=1
    fi
}

check_path "/Applications/ScrollSwitch.app"
check_path "${HOME}/Applications/ScrollSwitch.app"
check_path "${HOME}/Library/LaunchAgents/${LABEL}.plist"
check_path "${HOME}/Library/Preferences/${BUNDLE_ID}.plist"
check_path "${HOME}/Library/Application Support/ScrollSwitch"
check_path "${HOME}/Library/Caches/${BUNDLE_ID}"
check_path "${HOME}/Library/Saved Application State/${BUNDLE_ID}.savedState"
check_path "${HOME}/Library/Logs/ScrollSwitch.log"

if launchctl print "gui/$(id -u)/${LABEL}" >/dev/null 2>&1; then
    echo "  ✗ 残留：登录项仍注册在 launchd 中"
    LEFT=1
fi

if pgrep -x ScrollSwitch >/dev/null 2>&1; then
    echo "  ✗ 残留：进程仍在运行"
    LEFT=1
fi

FOUND="$(find "${HOME}/Library" -maxdepth 4 -iname "*scrollswitch*" 2>/dev/null | head -5)"
if [ -n "${FOUND}" ]; then
    echo "  ✗ 残留："
    echo "${FOUND}" | sed 's/^/      /'
    LEFT=1
fi

SYSTEM_WIDE="$(find /Library/LaunchAgents /Library/LaunchDaemons /Library/PrivilegedHelperTools -maxdepth 2 -iname "*scrollswitch*" 2>/dev/null | head -5)"
if [ -n "${SYSTEM_WIDE}" ]; then
    echo "  ✗ 残留（系统级）："
    echo "${SYSTEM_WIDE}" | sed 's/^/      /'
    LEFT=1
fi

echo "  系统「自然滚动」设置：$(defaults read -g com.apple.swipescrolldirection 2>/dev/null || echo "未设置")（本就未被修改）"

echo
if [ "${LEFT}" -eq 0 ]; then
    echo "卸载完成，本机没有留下任何 ScrollSwitch 相关文件。"
else
    echo "卸载完成，但上面列出的项目需要手动处理。"
fi
echo "（下载目录里的安装包与本脚本由你自行删除即可。）"

pause_exit "${LEFT}"
